package org.example;

public class PureSymbolicBaseNALU {

    private static final String MASTER_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÑñ";

    private static String getAlphabet(int base) {
        return MASTER_ALPHABET.substring(0, base);
    }

    public static char nextSymbol(char symbol, int base) {
        String alphabet = getAlphabet(base);
        int index = alphabet.indexOf(symbol);
        return alphabet.charAt((index + 1) % base);
    }

    public static char prevSymbol(char symbol, int base) {
        String alphabet = getAlphabet(base);
        int index = alphabet.indexOf(symbol);
        return alphabet.charAt((index - 1 + base) % base);
    }

    /**
     * Incrementa un número simbólico en Base N (Equivalente a sumar 1 hardware-level).
     */
    public static String increment(String num, int base) {
        String alphabet = getAlphabet(base);
        char zero = alphabet.charAt(0);
        char maxChar = alphabet.charAt(base - 1);

        if (num.isEmpty() || num.equals(String.valueOf(zero))) {
            return String.valueOf(alphabet.charAt(1 < base ? 1 : 0));
        }

        char lastChar = num.charAt(num.length() - 1);
        String prefix = num.substring(0, num.length() - 1);

        if (lastChar == maxChar) {
            // Desborde/Carry: incrementa el prefijo recursivamente y reinicia el dígito a 0
            String incPrefix = increment(prefix, base);
            return (incPrefix.isEmpty() ? String.valueOf(alphabet.charAt(1)) : incPrefix) + zero;
        } else {
            return prefix + nextSymbol(lastChar, base);
        }
    }

    /**
     * Decrementa un número simbólico en Base N.
     */
    public static String decrement(String num, int base) {
        String alphabet = getAlphabet(base);
        char zero = alphabet.charAt(0);
        char maxChar = alphabet.charAt(base - 1);

        if (num.equals(String.valueOf(zero))) {
            return (String.valueOf(zero));
        }

        char lastChar = num.charAt(num.length() - 1);
        String prefix = num.substring(0, num.length() - 1);

        if (lastChar == zero) {
            String decPrefix = decrement(prefix, base);
            return (decPrefix.equals(String.valueOf(zero)) ? "" : decPrefix) + maxChar;
        } else {
            String res = prefix + prevSymbol(lastChar, base);
            // Limpia ceros a la izquierda estructurales
            while (res.length() > 1 && res.charAt(0) == zero) {
                res = res.substring(1);
            }
            return res;
        }
    }

    /**
     * Suma pura por inducción estructural (Peano Arithmetic) adaptada a Base N.
     * Mueve los estados simbólicamente hasta agotar el segundo operando.
     */
    public static String pureAdd(String a, String b, int base) {
        String alphabet = getAlphabet(base);
        String zero = String.valueOf(alphabet.charAt(0));

        // Caso base: sumar cero (el primer símbolo del alfabeto) no altera el estado
        if (b.equals(zero)) {
            return a;
        }

        // Paso inductivo: A + B es estructuralmente idéntico a (Next(A) + Prev(B))
        return pureAdd(increment(a, base), decrement(b, base), base);
    }

    public static void main(String[] args) {
        int baseN = 64; // Probemos en Hexadecimal puro

        String a = "F";
        String b = "2";

        System.out.println("--- SUMA SIMBÓLICA PURA (PEANO) EN BASE " + baseN + " ---");
        System.out.println(a + " + " + b + " = " + pureAdd(a, b, baseN)); // F + 2 -> 11
    }
}