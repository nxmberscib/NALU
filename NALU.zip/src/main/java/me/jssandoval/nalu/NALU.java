package me.jssandoval.nalu;

import java.util.*;
import java.util.regex.*;
import java.math.BigInteger;

public class NALU {

    // ==========================================
    // 1. CLASE ALPHABET (Gestión de Símbolos)
    // ==========================================
    public static class Alphabet {
        private static final String MASTER_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÑñ";
        private final int base;
        private final String currentAlphabet;

        public Alphabet(int base) {
            if (base < 2 || base > MASTER_ALPHABET.length()) {
                throw new IllegalArgumentException("Base fuera de rango (2-" + MASTER_ALPHABET.length() + ")");
            }
            this.base = base;
            this.currentAlphabet = MASTER_ALPHABET.substring(0, base);
        }

        public int getBase() { return base; }
        public char getZero() { return currentAlphabet.charAt(0); }
        public char getSymbol(int index) { return currentAlphabet.charAt(index); }
        public int getIndex(char symbol) {
            int idx = currentAlphabet.indexOf(symbol);
            if (idx == -1) throw new IllegalArgumentException("Símbolo '" + symbol + "' no pertenece al alfabeto.");
            return idx;
        }
        public char nextSymbol(char symbol) { return currentAlphabet.charAt((getIndex(symbol) + 1) % base); }
        public char prevSymbol(char symbol) { return currentAlphabet.charAt((getIndex(symbol) - 1 + base) % base); }
        public String limpiarCeros(String num) {
            char zero = getZero();
            while (num.length() > 1 && num.charAt(0) == zero) { num = num.substring(1); }
            return num.isEmpty() ? String.valueOf(zero) : num;
        }
    }

    // ==========================================
    // 2. CLASE ALU (Aritmética Posicional por Estados)
    // ==========================================
    public static class ALU {
        private final Alphabet alphabet;
        public ALU(Alphabet alphabet) { this.alphabet = alphabet; }
        public Alphabet getAlphabet() { return alphabet; }

        public int compare(String a, String b) {
            a = alphabet.limpiarCeros(a); b = alphabet.limpiarCeros(b);
            if (a.length() != b.length()) return a.length() > b.length() ? 1 : -1;
            return a.compareTo(b);
        }

        public String increment(String num) {
            num = alphabet.limpiarCeros(num);
            char zero = alphabet.getZero();
            char maxChar = alphabet.getSymbol(alphabet.getBase() - 1);
            if (num.equals(String.valueOf(zero))) return String.valueOf(alphabet.getBase() > 1 ? alphabet.getSymbol(1) : zero);
            char lastChar = num.charAt(num.length() - 1);
            String prefix = num.substring(0, num.length() - 1);
            if (lastChar == maxChar) return alphabet.limpiarCeros(increment(prefix) + zero);
            else return prefix + alphabet.nextSymbol(lastChar);
        }

        public String decrement(String num) {
            num = alphabet.limpiarCeros(num);
            char zero = alphabet.getZero();
            char maxChar = alphabet.getSymbol(alphabet.getBase() - 1);
            if (num.equals(String.valueOf(zero))) throw new ArithmeticException("Underflow estructural.");
            char lastChar = num.charAt(num.length() - 1);
            String prefix = num.substring(0, num.length() - 1);
            if (lastChar == zero) return alphabet.limpiarCeros(decrement(prefix) + maxChar);
            else return alphabet.limpiarCeros(prefix + alphabet.prevSymbol(lastChar));
        }

        public String sumar(String a, String b) {
            a = alphabet.limpiarCeros(a); b = alphabet.limpiarCeros(b);
            String zeroStr = String.valueOf(alphabet.getZero());
            StringBuilder resultado = new StringBuilder();
            String carry = zeroStr;
            int i = a.length() - 1; int j = b.length() - 1;

            while (i >= 0 || j >= 0 || !carry.equals(zeroStr)) {
                String d1 = (i >= 0) ? String.valueOf(a.charAt(i)) : zeroStr;
                String d2 = (j >= 0) ? String.valueOf(b.charAt(j)) : zeroStr;
                String sumaColumna = zeroStr, cnt = zeroStr;

                while (!cnt.equals(d1)) { sumaColumna = increment(sumaColumna); cnt = increment(cnt); }
                cnt = zeroStr;
                while (!cnt.equals(d2)) { sumaColumna = increment(sumaColumna); cnt = increment(cnt); }
                cnt = zeroStr;
                while (!cnt.equals(carry)) { sumaColumna = increment(sumaColumna); cnt = increment(cnt); }

                int base = alphabet.getBase(); int idxTotal = 0;
                String tmp = sumaColumna;
                while (!tmp.equals(zeroStr)) { idxTotal++; tmp = decrement(tmp); }

                resultado.append(alphabet.getSymbol(idxTotal % base));
                carry = zeroStr;
                for (int c = 0; c < (idxTotal / base); c++) carry = increment(carry);
                i--; j--;
            }
            return alphabet.limpiarCeros(resultado.reverse().toString());
        }

        public String restar(String a, String b) {
            a = alphabet.limpiarCeros(a); b = alphabet.limpiarCeros(b);
            if (compare(a, b) < 0) throw new ArithmeticException("Resultado negativo no soportado.");
            StringBuilder resultado = new StringBuilder();
            int borrow = 0, base = alphabet.getBase(), i = a.length() - 1, j = b.length() - 1;

            while (i >= 0) {
                int d1 = alphabet.getIndex(a.charAt(i));
                int d2 = (j >= 0) ? alphabet.getIndex(b.charAt(j)) : 0;
                int sub = d1 - d2 - borrow;
                if (sub < 0) { sub += base; borrow = 1; } else { borrow = 0; }
                resultado.append(alphabet.getSymbol(sub));
                i--; j--;
            }
            return alphabet.limpiarCeros(resultado.reverse().toString());
        }

        public String multiplicar(String a, String b) {
            a = alphabet.limpiarCeros(a); b = alphabet.limpiarCeros(b);
            String zeroStr = String.valueOf(alphabet.getZero());
            if (a.equals(zeroStr) || b.equals(zeroStr)) return zeroStr;

            String resultadoFinal = zeroStr; int base = alphabet.getBase();
            for (int i = b.length() - 1; i >= 0; i--) {
                int valD2 = alphabet.getIndex(b.charAt(i));
                StringBuilder parcial = new StringBuilder();
                for (int k = 0; k < (b.length() - 1 - i); k++) parcial.append(zeroStr);

                String carry = zeroStr;
                for (int j = a.length() - 1; j >= 0; j--) {
                    int valD1 = alphabet.getIndex(a.charAt(j));
                    String prodCol = zeroStr, cnt = zeroStr;
                    for (int step = 0; step < (valD1 * valD2); step++) prodCol = increment(prodCol);
                    while (!cnt.equals(carry)) { prodCol = increment(prodCol); cnt = increment(cnt); }

                    int valProd = 0; String tmp = prodCol;
                    while (!tmp.equals(zeroStr)) { valProd++; tmp = decrement(tmp); }

                    parcial.append(alphabet.getSymbol(valProd % base));
                    carry = zeroStr;
                    for (int c = 0; c < (valProd / base); c++) carry = increment(carry);
                }
                if (!carry.equals(zeroStr)) parcial.append(carry);
                resultadoFinal = sumar(resultadoFinal, parcial.reverse().toString());
            }
            return alphabet.limpiarCeros(resultadoFinal);
        }

        public String[] dividir(String a, String b) {
            a = alphabet.limpiarCeros(a); b = alphabet.limpiarCeros(b);
            String zeroStr = String.valueOf(alphabet.getZero());
            if (b.equals(zeroStr)) throw new ArithmeticException("División por cero.");
            String cociente = zeroStr, residuo = a;

            while (compare(residuo, b) >= 0) {
                residuo = restar(residuo, b);
                cociente = increment(cociente);
            }
            return new String[]{alphabet.limpiarCeros(cociente), alphabet.limpiarCeros(residuo)};
        }
    }

    // ==========================================
    // 3. CLASE PARSER (Cuaderno de Resolución)
    // ==========================================
    public static class Parser {

        public static String aBase10(String numStr, Alphabet alphabet) {
            BigInteger result = BigInteger.ZERO;
            BigInteger baseNum = BigInteger.valueOf(alphabet.getBase());
            for (int i = 0; i < numStr.length(); i++) {
                int val = alphabet.getIndex(numStr.charAt(i));
                result = result.multiply(baseNum).add(BigInteger.valueOf(val));
            }
            return result.toString();
        }

        /**
         * Igual que aBase10, pero imprime el "cuaderno" del proceso siguiendo el
         * MISMO algoritmo y formato de tabla que el bloque de VERIFICACIÓN
         * (Base N -> Base 10) del laboratorio en Python: expansión posicional
         * (dígito * base^posición), de la posición más significativa a la menos
         * significativa, con una tabla Posición | Símbolo | Valor | Potencia | Subtotal.
         */
        public static String aBase10ConProceso(String numStr, Alphabet alphabet) {
            numStr = alphabet.limpiarCeros(numStr);
            int longitud = numStr.length();
            BigInteger baseNum = BigInteger.valueOf(alphabet.getBase());
            BigInteger sumaVerificacion = BigInteger.ZERO;

            System.out.println("\n=========================================================================");
            System.out.println("                   VERIFICACIÓN (BASE " + alphabet.getBase() + " A BASE 10)");
            System.out.println("=========================================================================\n");

            System.out.printf("%-10s | %-9s | %-7s | %-20s | %s%n",
                    "Posición", "Símbolo", "Valor", "Potencia (Base^Pos)", "Subtotal");
            System.out.println("-".repeat(75));

            for (int j = 0; j < longitud; j++) {
                int i = longitud - 1 - j; // posición: de la más significativa (izquierda) a la menos (derecha)
                char simbolo = numStr.charAt(j);
                int valorPos = alphabet.getIndex(simbolo);
                BigInteger peso = baseNum.pow(i);
                BigInteger subtotal = BigInteger.valueOf(valorPos).multiply(peso);
                sumaVerificacion = sumaVerificacion.add(subtotal);

                String infoPotencia = alphabet.getBase() + "^" + i + " = " + peso;
                String infoSimbolo = "'" + simbolo + "'";

                System.out.printf("D%-9d | %-9s | %-7d | %-20s | %s%n",
                        i, infoSimbolo, valorPos, infoPotencia, subtotal);
            }

            System.out.println("-".repeat(75));
            System.out.printf("%-53s %s%n", "SUMA TOTAL EN BASE 10:", sumaVerificacion);
            System.out.println("=========================================================================");

            return sumaVerificacion.toString();
        }

        public static void convertirAOtraBaseConProceso(String numStr, Alphabet sourceAlphabet, int targetBase) {
            BigInteger decimalVal = new BigInteger(aBase10(numStr, sourceAlphabet));
            Alphabet targetAlphabet = new Alphabet(targetBase);
            BigInteger baseDestino = BigInteger.valueOf(targetBase);

            System.out.println("\n=========================================================================");
            System.out.println("                     CONVERSIÓN (BASE 10 A BASE " + targetBase + ")");
            System.out.println("=========================================================================\n");
            System.out.println(" -> Valor intermedio en Base 10: " + decimalVal + "\n");

            String resultadoBaseDestino;

            if (decimalVal.equals(BigInteger.ZERO)) {
                resultadoBaseDestino = String.valueOf(targetAlphabet.getZero());
                System.out.println("  Paso 1: Valor 0 -> Símbolo: '" + targetAlphabet.getZero() + "'");
            } else {
                BigInteger tempB = decimalVal;
                resultadoBaseDestino = "";
                int pasoB = 1;

                System.out.printf("%-6s | %-50s | %-9s | %s%n",
                        "Paso", "Ecuación (Dividendo = Cociente * Base + Residuo)", "Símbolo", "Acumulado");
                System.out.println("-".repeat(92));

                while (tempB.compareTo(BigInteger.ZERO) > 0) {
                    BigInteger[] divRem = tempB.divideAndRemainder(baseDestino);
                    BigInteger cociente = divRem[0];
                    int residuo = divRem[1].intValue();
                    char caracter = targetAlphabet.getSymbol(residuo);
                    resultadoBaseDestino = caracter + resultadoBaseDestino;

                    String ecuacion = tempB + " = " + cociente + " * " + targetBase + " + " + residuo;
                    String infoSimbolo = residuo + " -> '" + caracter + "'";

                    System.out.printf("%-6d | %-50s | %-9s | %s%n",
                            pasoB, ecuacion, infoSimbolo, resultadoBaseDestino);

                    tempB = cociente;
                    pasoB++;
                }
            }

            System.out.println("\n -> Resultado final en Base " + targetBase + ": " + resultadoBaseDestino);
            System.out.println("=========================================================================");
        }

        public String resolverBaseN(String ecuacion, Map<String, String> memoria, ALU alu) {
            return resolverPasoAPaso(ecuacion, memoria, (left, op, right) -> {
                switch (op) {
                    case "+": return alu.sumar(left, right);
                    case "-": return alu.restar(left, right);
                    case "*": return alu.multiplicar(left, right);
                    case "/": return alu.dividir(left, right)[0];
                    case "%": return alu.dividir(left, right)[1];
                    default: throw new IllegalArgumentException("Operador desconocido");
                }
            });
        }

        public String resolverBase10(String ecuacion, Map<String, String> memoria) {
            return resolverPasoAPaso(ecuacion, memoria, (left, op, right) -> {
                BigInteger n1 = new BigInteger(left);
                BigInteger n2 = new BigInteger(right);
                switch (op) {
                    case "+": return n1.add(n2).toString();
                    case "-": return n1.subtract(n2).toString();
                    case "*": return n1.multiply(n2).toString();
                    case "/": return n1.divide(n2).toString();
                    case "%": return n1.remainder(n2).toString();
                    default: throw new IllegalArgumentException("Operador desconocido");
                }
            });
        }

        private String resolverPasoAPaso(String ecuacionOriginal, Map<String, String> memoria, OperadorBinario opBinario) {
            String eq = ecuacionOriginal.replaceAll("\\s+", "");

            System.out.println("   " + eq);
            for (Map.Entry<String, String> entry : memoria.entrySet()) {
                eq = eq.replaceAll("\\b" + entry.getKey() + "\\b", entry.getValue());
            }
            if (!eq.equals(ecuacionOriginal)) {
                System.out.println(" = " + eq);
            }

            Pattern patternBloque = Pattern.compile("([\\(\\[\\{])([^\\(\\[\\{\\)\\]\\}]+)([\\)\\]\\}])");
            Pattern opPri1 = Pattern.compile("([A-Za-z0-9Ññ]+)([\\*/%])([A-Za-z0-9Ññ]+)");
            Pattern opPri2 = Pattern.compile("([A-Za-z0-9Ññ]+)([\\+\\-])([A-Za-z0-9Ññ]+)");

            while (true) {
                Matcher mBloque = patternBloque.matcher(eq);

                if (mBloque.find()) {
                    String openP = mBloque.group(1);
                    String contenido = mBloque.group(2);
                    String closeP = mBloque.group(3);

                    // Se intenta operar dentro del contenido del bloque (prioridad 1, luego 2)
                    String nuevoContenido = intentarOperar(contenido, opPri1, opBinario)
                            .or(() -> intentarOperar(contenido, opPri2, opBinario))
                            .orElse(null);

                    if (nuevoContenido != null) {
                        eq = eq.substring(0, mBloque.start()) + openP + nuevoContenido + closeP + eq.substring(mBloque.end());
                    } else {
                        // No queda ningún operador dentro: se retiran los paréntesis, ya redujo a un solo valor
                        eq = eq.substring(0, mBloque.start()) + contenido + eq.substring(mBloque.end());
                    }
                    System.out.println(" = " + eq);
                    continue;

                } else {
                    var tempEq = eq;
                    // Ya no hay bloques: se opera directamente sobre la ecuación completa (prioridad 1, luego 2)
                    String nuevaEq = intentarOperar(eq, opPri1, opBinario)
                            .or(() -> intentarOperar(tempEq, opPri2, opBinario))
                            .orElse(null);

                    if (nuevaEq == null) break;

                    eq = nuevaEq;
                    System.out.println(" = " + eq);
                }
            }
            return eq;
        }

        /**
         * Busca la primera coincidencia del patrón en el texto, aplica el operador
         * binario correspondiente y devuelve el texto reconstruido con el resultado
         * sustituido. Devuelve Optional.empty() si el patrón no encuentra nada.
         * Centraliza la lógica que antes estaba repetida 4 veces en resolverPasoAPaso.
         */
        private Optional<String> intentarOperar(String texto, Pattern patron, OperadorBinario opBinario) {
            Matcher m = patron.matcher(texto);
            if (!m.find()) return Optional.empty();
            String res = opBinario.operar(m.group(1), m.group(2), m.group(3));
            return Optional.of(texto.substring(0, m.start()) + res + texto.substring(m.end()));
        }

        @FunctionalInterface
        interface OperadorBinario {
            String operar(String left, String op, String right);
        }
    }

    // ==========================================
    // 4. CLASE CLI (Consola e Interfaz)
    // ==========================================
    public static class CLI {
        public static void iniciar() {
            Scanner scanner = new Scanner(System.in);
            System.out.println("=======================================================");
            System.out.println("             CALCULADORA DE BASES (PEANO)");
            System.out.println("=======================================================");

            int base = 32;
            System.out.print("\nIngrese la Base numérica (2 - 64) [Defecto 32]: ");
            String baseInput = scanner.nextLine().trim();
            if (!baseInput.isEmpty()) base = Integer.parseInt(baseInput);

            Alphabet alphabet = new Alphabet(base);
            ALU alu = new ALU(alphabet);
            Parser parser = new Parser();

            System.out.println("\nEjemplo de formato: {[(A*B)+(A+C)]+(B%C)}");
            System.out.print("Ingrese la ecuación a resolver: ");
            String ecuacion = scanner.nextLine().replaceAll("\\s+", "");

            Set<String> variables = new TreeSet<>();
            Matcher matcher = Pattern.compile("[a-zA-Z_]\\w*").matcher(ecuacion);
            while (matcher.find()) variables.add(matcher.group());

            Map<String, String> memoriaRam = new HashMap<>();
            Map<String, String> memoriaDecimal = new HashMap<>();

            if (!variables.isEmpty()) {
                System.out.println("\n--- ASIGNACIÓN DE VARIABLES (EN BASE " + base + ") ---");
                for (String var : variables) {
                    while (true) {
                        System.out.print("Ingrese el valor para [" + var + "]: ");
                        String val = scanner.nextLine().trim();
                        try {
                            for (char c : val.toCharArray()) alphabet.getIndex(c);
                            String limpio = alphabet.limpiarCeros(val);

                            memoriaRam.put(var, limpio);
                            memoriaDecimal.put(var, Parser.aBase10(limpio, alphabet));
                            break;
                        } catch (Exception e) {
                            System.out.println(" -> Error: Carácter inválido. Intente de nuevo.");
                        }
                    }
                }
            }

            // --- 1. RESOLUCIÓN PASO A PASO EN BASE N ---
            System.out.println("\n=======================================================");
            System.out.println("   RESOLUCIÓN DE LA ECUACIÓN (BASE " + base + ")");
            System.out.println("=======================================================");

            String resultadoFinalBaseN = parser.resolverBaseN(ecuacion, memoriaRam, alu);

            // --- 2. PAUSA Y VERIFICACIÓN EN BASE 10 ---
            System.out.println("\n[PAUSA] Resultado final en Base " + base + ": " + resultadoFinalBaseN);
            System.out.println("Presiona [ENTER] para auditar la verificación en Base 10...");
            scanner.nextLine();

            // Ahora sí se muestra el proceso de conversión del resultado a Base 10
            String esperadoDecimal = Parser.aBase10ConProceso(resultadoFinalBaseN, alphabet);

            System.out.println("\n=======================================================");
            System.out.println("   VERIFICACIÓN DECIMAL (BASE 10)");
            System.out.println("=======================================================");

            String resultadoFinalDecimal = parser.resolverBase10(ecuacion, memoriaDecimal);

            System.out.println("\n=======================================================");
            System.out.println(" -> RESUMEN:");
            System.out.println(" -> Ecuacion (Traducida a Base 10) : " + esperadoDecimal);
            System.out.println(" -> Matemáticas Decimales Directas   : " + resultadoFinalDecimal);
            if (esperadoDecimal.equals(resultadoFinalDecimal)) {
                System.out.println(" -> El resultado Base 10 coincide.");
            } else {
                System.out.println(" -> El resultado base 10 no coincide.");
            }
            System.out.println("=======================================================");

            // --- 3. CONVERSIÓN ADICIONAL A OTRA BASE ---
            System.out.print("\n¿Deseas convertir el resultado a otra base? (s/n): ");
            String respuesta = scanner.nextLine().trim();
            if (respuesta.equalsIgnoreCase("s") || respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("sí")) {
                System.out.print("Ingrese la base de destino (2 - 64): ");
                int targetBase = Integer.parseInt(scanner.nextLine().trim());
                try {
                    Parser.convertirAOtraBaseConProceso(resultadoFinalBaseN, alphabet, targetBase);
                } catch (Exception e) {
                    System.out.println(" -> Error en la conversión: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        CLI.iniciar();
    }
}